<?php
    header("location:where_i5_flag.php");
    echo "<!-- CNSS{200_HTTP_OK!}";